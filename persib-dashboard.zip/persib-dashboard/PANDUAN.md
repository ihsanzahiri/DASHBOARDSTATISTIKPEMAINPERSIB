# Panduan Dashboard PERSIB

## Isi paket
| File / folder | Fungsi |
|---|---|
| `index.html` | Dashboard lengkap (tampilan, grafik, perhitungan, dan data bawaan) |
| `assets/foto/` | 29 foto pemain (`nama-pemain.png`) |
| `assets/banner.jpg` | Banner header |
| `DATA_PERSIB.xlsx` | Data pemain untuk diunggah ke Google Sheets (tab `Data`, `Kompetisi`, `Info`) |

Semua angka (Gol+Assist, per 90 menit, peringkat, grafik) dihitung otomatis oleh `index.html`.
Di spreadsheet cukup isi angka mentah.

## 1. Taruh data di Google Sheets
1. Upload `DATA_PERSIB.xlsx` ke Google Drive, buka dengan Google Sheets.
2. Klik **Bagikan > Akses umum > Siapa saja yang memiliki link > Pelihat**.
3. Jangan ganti nama tab (`Data`, `Kompetisi`, `Info`) dan judul kolom baris 1.

## 2. Hosting di GitHub Pages
1. Buat repository publik, upload **`index.html` dan folder `assets`**.
2. Settings > Pages > Deploy from a branch > `main` / root > Save.
3. Buka `https://USERNAME.github.io/NAMA-REPO/`.

## 3. Hubungkan spreadsheet ke web
Buka dashboard, klik **🔗 Sumber Data** (pojok kanan atas), tempel link Google Sheets, klik **Simpan & hubungkan**.
Setelah itu data berubah otomatis tiap 60 detik saat sheet diedit.

Penting: link yang ditempel tersimpan di browser tersebut saja. Agar dosen/pengunjung lain melihat data live:
- klik **Salin link dashboard** lalu bagikan link itu (berbentuk `.../index.html?sheet=ID`), atau
- buka `index.html` dengan teks editor, isi `SHEET_ID: "ID_SHEET"` di bagian atas skrip, lalu upload ulang ke GitHub.

Indikator kanan atas: **LIVE** (terhubung), **Data cadangan** (sheet gagal dibaca, data terakhir tetap tampil), **Data bawaan** (belum ada link).

## Mengisi data
- **Data**: satu baris per pemain; Posisi `GK/DF/MF/FW`; kolom lain angka.
- **Kompetisi**: per kompetisi; nama pemain harus sama persis dengan tab Data. Kuning ACL Two dikosongkan (bukan 0) bila belum ada.
- **Info**: tanggal data (`2026-11-04`), musim, sumber, `min_menit`, catatan.
- **Pemain baru**: tambah baris di bawah tab Data dan Kompetisi.
- **Foto**: simpan di `assets/foto/` dengan nama huruf kecil tanpa spasi/aksen, contoh `balsa-sekulic.png` (juga bisa `.webp/.jpg`). Tanpa foto tampil inisial. Faris Abdul belum punya foto.
